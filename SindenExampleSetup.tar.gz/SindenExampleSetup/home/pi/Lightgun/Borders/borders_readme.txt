Put the retroarch borders here:
/opt/retropie/configs/all/retroarch/overlay
