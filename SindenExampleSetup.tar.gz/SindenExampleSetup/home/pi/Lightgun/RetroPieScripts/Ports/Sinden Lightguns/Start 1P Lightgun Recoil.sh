#!/bin/bash
/home/pi/RetroPie/roms/ports/Sinden\ Lightguns/Turn\ Off\ Lightguns.sh
rm /home/pi/Lightgun/Player1/LightgunMono.exe.config
cp /home/pi/Lightgun/LightgunMono.exe.config.recoil /home/pi/Lightgun/Player1/
sudo mono-service /home/pi/Lightgun/Player1/LightgunMono.exe
