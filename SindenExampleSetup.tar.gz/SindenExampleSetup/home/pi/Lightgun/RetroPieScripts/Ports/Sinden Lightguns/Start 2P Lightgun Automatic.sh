#!/bin/bash
/home/pi/RetroPie/roms/ports/Sinden\ Lightguns/Turn\ Off\ Lightguns.sh
rm /home/pi/Lightgun/Player1/LightgunMono.exe.config
rm /home/pi/Lightgun/Player2/LightgunMono2.exe.config
cp /home/pi/Lightgun/LightgunMono.exe.config.auto /home/pi/Lightgun/Player1/
cp /home/pi/Lightgun/LightgunMono2.exe.config.auto /home/pi/Lightgun/Player2/
sudo mono-service /home/pi/Lightgun/Player1/LightgunMono.exe
mono-service /home/pi/Lightgun/Player2/LightgunMono2.exe
