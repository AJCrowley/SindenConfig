#!/bin/bash
/home/pi/RetroPie/roms/ports/Sinden\ Lightguns/Turn\ Off\ Lightguns.sh
rm /home/pi/Lightgun/Player1/LightgunMono.exe.config
rm /home/pi/Lightgun/Player2/LightgunMono2.exe.config
cp /home/pi/Lightgun/LightgunMono.exe.config /home/pi/Lightgun/Player1/
cp /home/pi/Lightgun/LightgunMono2.exe.config /home/pi/Lightgun/Player2/
mono /home/pi/Lightgun/Player2/LightgunMono2.exe sdl 30
