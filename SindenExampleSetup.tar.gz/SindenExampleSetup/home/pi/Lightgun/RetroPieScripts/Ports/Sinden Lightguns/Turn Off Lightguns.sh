#!/bin/bash
sudo pkill "mono"
sudo rm /tmp/LightgunMono* -f
