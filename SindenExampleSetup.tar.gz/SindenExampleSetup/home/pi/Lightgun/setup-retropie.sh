cp -rv RetroPieScripts/Ports/Sinden\ Lightguns /home/pi/RetroPie/roms/ports/
cp -v Borders/RetroArchBorders/* /opt/retropie/emulators/retroarch/overlays/
for f in /home/pi/RetroPie/roms/ports/Sinden\ Lightguns/*.sh; do chmod -v 777 $f; done
